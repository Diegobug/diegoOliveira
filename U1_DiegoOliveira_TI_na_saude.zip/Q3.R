require(rvest) # importa a biblioteca rvest
library(stringr) #importa a biblioteca stringr
library(sp)
library(RColorBrewer)
library(ggplot2)
library(ggmap)

setwd("/home/diego/Desktop/TI_na_saude/mapas") # Define o diretorio de trabalho
evitaveis = read.csv('causasevitaveis.csv',header=TRUE,as.is=TRUE, fileEncoding = "latin1") #ler csv
evitaveis$Obitos[ evitaveis$Obitos == "-" ] <- 0 # troca - por 0
evitaveis <- evitaveis[-168,] #remove total
evitaveis$Obitos <- as.numeric(evitaveis$Obitos) # Converte os caracteres em numericos

Natal = evitaveis$Obitos[which(evitaveis$Municipio=="Natal")]
Caico = evitaveis$Obitos[which(evitaveis$Municipio=="Caicó")]
Mossoro = evitaveis$Obitos[which(evitaveis$Municipio=="Mossoró")]
Pau_dos_Ferros = evitaveis$Obitos[which(evitaveis$Municipio=="Pau dos Ferros")]
Currais_Novos = evitaveis$Obitos[which(evitaveis$Municipio=="Currais Novos")]

cidades<-read_html("http://cidades.ibge.gov.br/download/mapa_e_municipios.php?lang=&uf=rn") %>%
  html_table(fill=TRUE)

base<-data.frame(cidades[[1]][c(1,4)]) # Selecionando os dados de interesse
names(base)<-c("cidade","pop2010") # Nomeando as colunas
row.names(base)<-1:168
base$pop2010<-str_replace_all(base$pop2010,"\\.","") # Retira os pontos
base$pop2010[is.na(base$pop2010)] <- 0# Substitui valores NAs por zeros
base <- head(base,-1)# Remove a ultima linha da tabela
base$pop2010<-as.numeric(base$pop2010) # Converte os caracteres em numericos
head(base)

br <- readRDS("BRA_adm2.rds") # Importa os poligonos do arquivo no diretorio de trabalho
rn = (br[br$NAME_1=="Rio Grande do Norte",]) # Filtrando apenas os municípios do RN


#plot(rn[rn$NAME_2=="Natal",], add=T, col="red")

rn$NAME_2[which(rn$NAME_2=="Governador Dix-Sept Rosad")]<-"Governador Dix-Sept Rosado"
rn$NAME_2[which(rn$NAME_2=="Lagoa de Anta")]<-"Lagoa d`Anta"
rn$NAME_2[which(rn$NAME_2=="Lagoas de Velhos")]<-"Lagoa de Velhos"
rn$NAME_2[which(rn$NAME_2=="Jardim-Piranhas")]<-"Jardim de Piranhas"
rn$NAME_2[which(rn$NAME_2=="Olho-d'Água do Borges")]<-"Olho-d`Água do Borges"
rn$NAME_2[which(rn$NAME_2=="Passabém")]<-"Passagem"
rn$NAME_2[which(rn$NAME_2=="Santana")]<-"Santana do Seridó"
rn$NAME_2[which(rn$NAME_2=="Junco")]<-"Messias Targino"
rn$NAME_2[which(rn$NAME_2=="São Miguel de Touros")]<-"São Miguel do Gostoso"
rn$NAME_2[which(rn$NAME_2=="Presidente Juscelino")]<-"Serra Caiada"
rn$NAME_2[which(rn$NAME_2=="Groaíras")]<-"Grossos"

rn <- rn[-109,] # remove Poço dantas 
rn <- rn[-41,] # remove Fernando de Noronha
# Define o nome das cidade-alvos – a ser apresentada como label no mapa
nomes = c(Natal, Caico, Mossoro, Pau_dos_Ferros, Currais_Novos)
# Define or argumentos de busca para as cidade-alvos – a ser usada pelo ggmap
nam = c("Natal+Brazil+RN","Caicó+Brazil+RN","Mossoró+Brazil+RN","Pau dos Ferros+Brazil+RN","Currais Novos+Brazil+RN")
# Busca a geolocalização (Google) para cada cidade
pos = geocode(nam)
# Define a posição dos labels como sendo um pouco acima dos pontos
tlat = pos$lat+0.05

cities = data.frame(nomes, pos$lon,pos$lat,tlat)
# Nomeia as colunas de longitude e latitude
names(cities)[2] = "lon"
names(cities)[3] = "lat"
# Criando os labels
text1 = list("panel.text", cities$lon, cities$tlat, cities$nomes,col="black", cex = 0.5)
# Criando os apontamentos
mark1 = list("panel.points", cities$lon, cities$lat, col="blue")
#rndata <- data.frame(rn)

rn <- merge(x=rn, y=base, by.x="NAME_2", by.y="cidade") # Faz um merge dos dataframes
# Criando os intervalos e classificando
col_no = as.factor(cut(rn$pop2010, breaks = c(0,3000,10000,100000,300000,500000,800000,1000000), labels=c("<3k", "3k-10k", "10k-
100k","100k-300k", "300k-500k", "500k-800k", ">800k"), right= FALSE))
# Nomeando os intervalos – irá aparecer na legenda do grafico
levels(col_no) = c("<3k", "3k-10k", "10k-100k","100k-300k", "300k-500k", "500k-800k", ">800k")
# Adicionando a informação da categoria no dataframe
rn$col_no = col_no
myPalette = brewer.pal(7,"Greens")

png(filename="Q3.png", width = 1374, height = 1148)
spplot(rn, "col_no", sp.layout=list(text1,mark1), col.regions=myPalette, main="Mortes evitáveis - até 5 anos de idade",cex=3)
dev.off()